---
name: python-code-reviewer
description: Review, run, debug, and verify approved Python modeling code against its code plan, data contract, method decision, risk conditions, and experiment outputs, saving one compact JSON review.
---

# Preconditions

- Python code and `code/Qx/qx_code_plan.md` exist.
- Approved method decision, method card, data profile, and relevant run summary are available.
- Required inputs are accessible.

# Workflow

1. Resolve the approved main and usable baseline. Flag scripts for unapproved candidates unless a fallback activation exists.
2. Inspect and run the code in the intended order.
3. Evaluate required checks:
   - `syntax`: imports, execution, exceptions, and obvious runtime faults.
   - `input_contract`: paths, fields, units, shapes, missing-data handling, raw-data protection, applicable information boundaries, required upstream artifact identity/version/hash/freshness/uncertainty, any approved prospective analysis-domain rule/mask, and exact audited-to-parsed-to-excluded/eligible-to-used row/entity reconciliation. Reject unexplained losses and undeclared main/baseline population differences.
   - `method_alignment`: formulas, objectives, constraints, assumptions, main/baseline roles, and fallback scope match the approved plan; reject forbidden future information and unapproved objective scalarization. For an applicable operating-point contract, verify group isolation and that threshold/policy selection uses training/calibration data only, never outer-evaluation labels.
   - `candidate_screening`: when applicable, proxy and final evaluators match the plan; feasibility anchors, coverage/diversity strata, and out-of-rank exploration are retained; rejection counts reconcile; interacting candidates use the actual composition operator; a failed prefix invokes only the allowed bounded diagnosis; and any continuous universal-constraint certificate has the planned reduction or error bound.
   - `reproducibility`: seed, deterministic setup, dependency/runtime record, and rerun consistency.
   - `output_contract`: saved tables/metrics/figures, valid run summary, comparable main/baseline metrics, per-method objective values, constraint violations, degeneracy evidence, fallback-trigger state, output-obligation status, and deterministic per-method output fingerprints. Any infeasible output fails even if its total objective is better. For abstention/triage, actions must be disjoint and exhaustive, abstentions must not count as negatives, and coverage/deferral plus the hard metric on its declared population must be reported under identical main/baseline semantics.
4. Add risk-specific checks only when relevant, such as leakage, constraint feasibility, numerical stability, or scale.
5. If asked to fix findings, make minimal changes, rerun affected checks, and record the repair. Otherwise report findings without changing code.
6. Save `code/Qx/reviews/qx_python_review.json`.

# Review Schema

The versioned schema linked below is the only machine contract; do not copy legacy examples.

Statuses are `PASS`, `FAIL`, or `NOT_APPLICABLE` with a reason. `NOT_APPLICABLE` is valid for genuinely static/no-dependency contract fields. Any required `FAIL` blocks G3; a better aggregate objective never overrides a failed named check.

# Rules

- Do not pad evidence to reach a count.
- Do not fabricate execution or outputs.
- Do not approve a toy diagnostic reference as the official baseline.
- Do not silently change mathematical meaning.
- Fail the applicable check for lookahead, unapproved scalarization, an infeasible output, or a missing, stale, identity-mismatched, or uncertainty-incompatible required upstream artifact.
- Fail `input_contract` when a structure-dependent calculation uses observations outside its evidenced eligible domain, changes the domain after seeing outcome quality, omits the approved mask/rule, or merely warns about ineligible observations while retaining them.
- Fail `input_contract` when audited rows/entities do not reconcile through exclusions to eligible and used populations, any exclusion reason is not prospectively authorized, or main and baseline use different comparison populations without an approved method-level exception.
- Fail the applicable named check when an operating threshold/policy reads outer-evaluation labels, repeated entities cross calibration/evaluation partitions, hard-constraint stability evidence is missing, or an abstention is hidden or scored as an ordinary negative.
- Fail `candidate_screening` when proxy truncation discards declared anchors/coverage/exploration, rejection counts do not reconcile, prefix exhaustion is called infeasibility without the bounded diagnosis, joint behavior is replaced by unproved standalone-score addition, or a continuous certificate is unsupported.
- Do not create success logs beyond the review JSON.
- Treat code newer than its review as requiring the affected checks to rerun, not necessarily the entire pipeline.

# Verification

- Every required named check has concrete evidence.
- Main and baseline are approved and comparable.
- Run summary and on-disk outputs agree.
- Static contract checks still run when execution cannot; never classify an unchecked violation as a pass.
- Applicable analysis-domain selection is prospective and the run summary proves the exact rule used, including exclusions.
- Applicable population reconciliation is arithmetic, reason-coded, and tied to one declared main/baseline comparison identity.
- Applicable operating-point review proves group-safe training-only calibration, common action semantics, hard-constraint accounting, and explicit coverage/deferral.
- Applicable screening review proves feasibility/interaction preservation, and output review exposes obligations plus stable identities for every selectable method output.
- Review verdict follows check statuses.

# Structural method handoff

When the method card cites a solution playbook, read that specific file via [the local index](../method-selector/references/solution-playbooks.md). Preserve its task-specific mathematical/input/output mapping and apply only relevant validation checks within existing plan, review or robustness artifacts. Adapt a runnable baseline to all real task obligations; synthetic examples never replace contest evidence. A language port needs its own execution evidence. No additional choice card or artifact is required merely for using a playbook.

# R6 canonical machine contract

Authoritative JSON schemas: [review](../workflow-orchestrator/schemas/review.schema.json). All new machine records use schema_version=2 and artifact_type; extension fields belong under extensions. JSONL decisions validate each record with decision.schema.json.

Read [paths and artifact ownership](../workflow-orchestrator/references/workspace-contract.md) for exact destinations and [gate execution](../workflow-orchestrator/references/gate-runtime.md) for command semantics. Markdown is a readable explanation, never an independent PASS/state source. After writing an artifact, validate the relevant gate; do not hand-write a passing gate result or reuse a stale result. Human/semantic judgment and machine validation are separate.
